namespace ATIVIDADE_AVALIATIVA
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            cadastrar cadastro = new cadastrar();
            cadastro.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            buscar buscar = new buscar();
            buscar.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            excluir exclui = new excluir();
            exclui.Show();
        }
    }
}


//������������������������



